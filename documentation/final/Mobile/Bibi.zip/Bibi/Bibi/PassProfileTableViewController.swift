//
//  PassProfileTableViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 10/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit
import SwiftValidator


class PassProfileTableViewController: UITableViewController ,ValidationDelegate, UITextFieldDelegate {
    
    let cellReuseIdentifier = "pass-profile-cell"
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var emailErrorLabel: UILabel!
    
    @IBOutlet weak var telphone: UITextField!
    @IBOutlet weak var telphoneError: UILabel!
    
    @IBOutlet weak var currentPassword: UITextField!
    @IBOutlet weak var currentPasswordError: UILabel!
    
    @IBOutlet weak var newPassword: UITextField!
    @IBOutlet weak var newPasswordError: UILabel!
    
    @IBOutlet weak var confirmPassword: UITextField!
    @IBOutlet weak var confirmPasswordError: UILabel!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var updatingEmail: Bool = false
    var profile : Profile?
    
    //cocoa pods validator
    let validator = Validator()
    
    //MARK: - INIT
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.startsListeningToServerFeedbackEvent()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //Monitor if the internet connection changed
        self.includeNetworkObserver()
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.removeNetworkObserver()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.obtainUser()
        
        self.email.delegate = self
        self.telphone.delegate = self
        self.currentPassword.delegate = self
        self.newPassword.delegate = self
        self.confirmPassword.delegate = self
        initialize()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func obtainUser(){
        if let user = ServerManager.user {
            self.profile = Profile(name: user.name, email: user.email, password: user.password, telephone: user.telphone)
        }
        
        
    }
    
    func initialize(){
        self.activityIndicator.hidesWhenStopped = true
        self.name.text = self.profile!.name
        self.email.text = self.profile!.email
        self.telphone.text = self.profile!.telephone
        self.setValidation()
    }
    
    func setValidation(){
        
        validator.styleTransformers(success:{ (validationRule) -> Void in
            // clear error label
            validationRule.errorLabel?.hidden = true
            validationRule.errorLabel?.text = ""
            validationRule.textField.layer.borderColor = ProjectColors.navigationGreenColor.CGColor
            validationRule.textField.layer.borderWidth = 0.5
            
            }, error:{ (validationError) -> Void in
                validationError.errorLabel?.hidden = false
                validationError.errorLabel?.text = validationError.errorMessage
                validationError.textField.layer.borderColor = UIColor.redColor().CGColor
                validationError.textField.layer.borderWidth = 1.0
        })
        
    }
    
    // MARK: - Actions
    
    @IBAction func disconnect(sender: AnyObject) {
        
        UserDefaultsLogin.deleteDefaultsDisconnect()
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    @IBAction func finishedEditingEmail(sender: AnyObject) {
        
        validator.registerField(email, errorLabel: emailErrorLabel, rules: [RequiredRule(message: "Campo obrigatório") , EmailRule(message: "Email inválido")])
        validator.validate(self)
    }
    
    @IBAction func finishedEditingTelphone(sender: AnyObject) {
        validator.registerField(telphone, errorLabel: telphoneError, rules: [RequiredRule(message: "Campo obrigatório") ,MinLengthRule(length: 8)])
        validator.validate(self)
    }
    
    @IBAction func finishedEditingCurrentPassword(sender: AnyObject) {
        validator.registerField(currentPassword, errorLabel: currentPasswordError, rules: [RequiredRule(message: "Campo obrigatório")])
    }
    
    @IBAction func finishedEditingNewPass(sender: AnyObject) {
        validator.registerField(newPassword, errorLabel: newPasswordError, rules: [RequiredRule(message: "Campo obrigatório")])
    }
    
    
    @IBAction func finishedEditingConfirm(sender: AnyObject) {
        validator.registerField(confirmPassword, errorLabel: confirmPasswordError, rules: [RequiredRule(message: "Campo obrigatório"), ConfirmationRule(confirmField: newPassword, message: "As senhas não correspondem"),ConfirmationRule(confirmField: newPassword, message: "Os emails não correspondem")])
        validator.validate(self)
    }
    
    // MARK: - Table view data source
    
    //setup the header design
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel!.textColor = UIColor(red:0.00, green:0.37, blue:0.41, alpha:1.0)
        let font = UIFont(name: "Kohinoor Devanagari", size: 16.0)
        headerView.textLabel!.font = font!
    }
    
    //MARK : Text field
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    // MARK: ValidationDelegate Methods
    
    func verifyUpdatePassword(){
        print("verify update password")
        if self.currentPassword.text != "" && self.newPassword.text != "" && self.confirmPassword.text != "" && self.newPassword.text == self.confirmPassword.text {
            
            if !self.updatingEmail {
                print("update password ")
                self.activityIndicator.startAnimating()
                
                ServerManager.updatePassengerPassword(self.currentPassword.text!, newPassword: self.newPassword.text!, completionHandler: { (success, errorMessage) -> Void in
                    
                    //async
                    
                    dispatch_async(dispatch_get_main_queue()) {
                        
                        if self.isViewLoaded() && self.view.window != nil {
                            self.activityIndicator.stopAnimating()
                        }
                        
                        EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                        
                    }
                })
            }
        }
    }
    
    
    func verifyUpdate(){
        
        print("verify update")
        
        if self.email.text != "" && self.email.text != self.profile?.email{
            self.activityIndicator.startAnimating()
            print("update email ")
            
            ServerManager.updatePassengerEmail(self.email.text!, completionHandler: {  (success, errorMessage) -> Void in
                //async
                self.updatingEmail = true
                dispatch_async(dispatch_get_main_queue()) {
                    if self.isViewLoaded() && self.view.window != nil {
                        self.activityIndicator.stopAnimating()
                    }
                    self.updatingEmail = false
                    EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                }
            })
        }
        
        if self.telphone.text != "" && self.telphone.text != self.profile?.telephone{
            
            
            if !self.updatingEmail {
                print("update telphone ")
                self.activityIndicator.startAnimating()
                ServerManager.updatePassengerTelphone(self.self.telphone.text!, completionHandler: { (success, errorMessage) -> Void in
                    dispatch_async(dispatch_get_main_queue()) {
                        if self.isViewLoaded() && self.view.window != nil {
                            self.activityIndicator.stopAnimating()
                        }
                        
                        if !success {
                            EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                        }else {
                            self.profile?.telephone = self.telphone.text!
                        }
                    }
                })
            }
            
        }
        
    }
    
    func validationSuccessful() {
        print("Validation Success!")
        //send form
        
        verifyUpdate()
        verifyUpdatePassword()
    }
    
    
    func validationFailed(errors:[UITextField:ValidationError]) {
        print("Validation FAILED!")
    }
    
    //MARK: SEGUE
    
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        if identifier == "profile"{
            print("segue profile")
        }
        
        return true
    }
}
