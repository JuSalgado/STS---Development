//
//  Destiny.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class Destiny : NSObject{
    
    //origin - way to and around
    var originName : String
    var originLocation : Location
    var originStartHour : NSDate = NSDate()
    var originBackHour : NSDate = NSDate()
    
    //destination
    var destinationName : String
    var destinationLocation : Location
    var destinationStartHour : NSDate = NSDate()
    var destinationBackHour : NSDate = NSDate()
    
    //ordenated passengers
    var passengers : [Passenger]
    
    var driver : Driver
    
    //date formatter
    var formatter : NSDateFormatter = NSDateFormatter()
    
    //init
    init(originName : String , originLocation : Location, originStartHour : NSDate  , originBackHour : NSDate , destinationName : String, destinationLocation : Location , destinationStartHour : NSDate , destinationBackHour : NSDate , passengers : [Passenger] , driver: Driver ) {
        self.originName = originName
        self.originLocation = originLocation
        self.originStartHour = originStartHour
        self.originBackHour = originBackHour
        self.destinationName = destinationName
        self.destinationLocation = destinationLocation
        self.destinationStartHour = destinationStartHour
        self.destinationBackHour = destinationBackHour
        self.passengers = passengers
        self.driver = driver
    }
    
    func dateToHourString(date: NSDate) -> String {
        formatter.dateFormat = "HH:mm"
        return formatter.stringFromDate(date)
    }
    
    func originStartHourString() -> String {
        return dateToHourString(originStartHour)
    }
    
    func originBackHourrString() -> String {
        return dateToHourString(originBackHour)
    }
    
    func destinationStartHourString() -> String {
        return dateToHourString(destinationStartHour)
    }
    func destinationBackHourString() -> String {
        return dateToHourString(destinationBackHour)
    }
}