//
//  DrivMapViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 10/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit
import MapKit
import AddressBook

class DrivMapViewController: RouteMapViewController,  LocationManagerDelegate {
    
    //track driver location
    var driverLocations: [Location] = []
    
    //MARK : INIT
    
    override func initialize(){
        
        //super
        super.initialize()
        
        self.mapView.delegate = self
        
        
        //generate route
        self.initRoute()
        
        //driver location tracker
        LocationManager.sharedInstance.delegate = self
        LocationManager.sharedInstance.startTrackingLocation()
        
        
        //blinking blue dot to our map to show where we currently are
        self.mapView.showsUserLocation = true
        self.mapView.setUserTrackingMode(MKUserTrackingMode.None, animated: true)
        
        warnNeedForLocationWhenInUseAccess()
        
        
    }
    
    
    
    // - MARK: LocationManager delegate methods
    func locationManager(locationManager: LocationManager, didUpdateUserLocation location: Location) {
        print("\(location.latitude) \(location.longitude)")
        self.mapView.showsUserLocation = true
        self.driverLocations.append(location)
        
        ServerManager.sendDriverLocationsToServer(self.driverLocations) {  (success, errorMessage) -> Void in
            
            //async
            
            dispatch_async(dispatch_get_main_queue()) {
                EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
            }
        }
    }
    
    
}
