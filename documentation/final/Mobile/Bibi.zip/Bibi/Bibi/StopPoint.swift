//
//  StopPoint.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/09/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit
import MapKit
import AddressBook

class StopPoint: NSObject , MKAnnotation {

    let title: String?
    let coordinate: CLLocationCoordinate2D
    let index : Int
    
    init(title : String , index : Int,  coordinate: CLLocationCoordinate2D){
        self.coordinate = coordinate
        self.index = index
        self.title = title
        super.init()
    }
    
    var subtitle: String? {
        return title
    }
    
    // MARK: - MapKit related methods

    // annotation callout opens this mapItem in Maps app
    func mapItem() -> MKMapItem {
        let addressDict = [String(kABPersonAddressStreetKey): self.subtitle!]
        let placemark = MKPlacemark(coordinate: self.coordinate, addressDictionary: addressDict)
        
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = self.title
        
        return mapItem
    }
   
}
