//
//  UIViewControllerExtensionForLocation.swift
//  PetMatch
//
//  Created by Pedro Figueiredo on 7/10/15.
//  Copyright (c) 2015 B-B-BOOM!. All rights reserved.
//

import Foundation
import UIKit
import MapKit

extension UIViewController {
    
    func warnNeedForLocationWhenInUseAccess() {
        let authorizationStatus: CLAuthorizationStatus = CLLocationManager.authorizationStatus()
        
        if authorizationStatus == CLAuthorizationStatus.Denied {
            //            let productName: String = NSBundle.mainBundle().infoDictionary!["CFBundleName"] as! String
            let alertVC = UIAlertController(title: "Location access not enabled", message: "You need to enable location access for this app in the Settings.", preferredStyle: .ActionSheet)
            alertVC.addAction(UIAlertAction(title: "Open Settings", style: .Default) { value in
                UIApplication.sharedApplication().openURL(NSURL(string: UIApplicationOpenSettingsURLString)!)
                })
            alertVC.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
            
            self.presentViewController(alertVC, animated: true, completion: nil)
        }
    }
    
    //MARK : DEAL WITH ERROR
    
    func showAlertController(code : Int){
        
        let title = self.getMessageByCode(code).0
        let message = self.getMessageByCode(code).1
        
        let alertController = UIAlertController(title: title, message:
            message, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    func showAlertControllerWithMessage(message : String){
        
        let alertController = UIAlertController(title: "Sentimos muito", message:
            message, preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    
    //MARK: -Network status
    func networkStatusChanged(notification: NSNotification){
        
        //let userInfo = notification.userInfo
        
        let status = Reach().connectionStatus()
        switch status {
        case .Unknown, .Offline:
            print("Not connected")
            showAlertController(0)
        case .Online(.WWAN): break
            //            print("Connected via WWAN")
        case .Online(.WiFi): break
            //            print("Connected via WiFi")
        }
        
        
    }
    
    func includeNetworkObserver(){
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("networkStatusChanged:"), name: ReachabilityStatusChangedNotification, object: nil)
        Reach().monitorReachabilityChanges()
    }
    
    func removeNetworkObserver(){
        NSNotificationCenter.defaultCenter().removeObserver(self, name: ReachabilityStatusChangedNotification, object: nil)
    }
    
    //MARK: - Utils
    func UIColorFromRGB(colorCode: String, alpha: Float = 1.0) -> UIColor {
        let scanner = NSScanner(string:colorCode)
        var color:UInt32 = 0;
        scanner.scanHexInt(&color)
        
        let mask = 0x000000FF
        let r = CGFloat(Float(Int(color >> 16) & mask)/255.0)
        let g = CGFloat(Float(Int(color >> 8) & mask)/255.0)
        let b = CGFloat(Float(Int(color) & mask)/255.0)
        
        return UIColor(red: r, green: g, blue: b, alpha: CGFloat(alpha))
    }
    
    func dateFormat(destinyDate : NSDate) -> String{
        let formatter = NSDateFormatter()
        formatter.timeStyle = .ShortStyle
        
        let date = formatter.stringFromDate(destinyDate)
        
        return date
    }
    
    func getMessageByCode(code : Int) -> (String , String) {
        
        switch code {
            
        case 0 :
            return ("Erro de conexão", "Aparentemente você não está conectado a internet, conecte-se e volte a navegar.")
        case 1 :
            return ("Sentimos muito", "Houve um erro ao conectar-se com o servidor, tente novamente mais tarde.")
        case 2 :
            return ("Sentimos muito", "Houve um erro ao efetuar sua solicitação, tente novamente mais tarde.")
        case 3:
            return ("Sentimos muito", "Parte da rota não pode ser calculada, tente novamente mais tarde.")
        default:
            return ("Sentimos muito", "Um comportamento inesperado foi obtido, tente novamente mais tarde.")
        }
        
    }
    
    func startsListeningToServerFeedbackEvent() {
        EventsTrigger.events.listenTo("serverFeedbackMessage") { [unowned self] (message) -> () in
            self.showServerFeedbackMessage(message! as! String)
        }
        
        EventsTrigger.events.listenTo("serverFeedbackCode") { [unowned self] () -> () in
            self.showServerFeedbackCode()
        }
    }
    
    func showServerFeedbackMessage(message: String) {
        if self.isViewLoaded() && self.view.window != nil {
            self.showAlertControllerWithMessage(message)
        }
    }
    
    func showServerFeedbackCode() {
        if self.isViewLoaded() && self.view.window != nil {
            self.showAlertController(1)
        }
    }
}