//
//  Profile.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class Profile: NSObject {
    
    //just read
    var name : String = ""
    
    //alter too
    var email : String = ""
    
    var password : String = ""
    
    var newPassword : String = ""
    
    var telephone : String = ""
    
    //init
    init(name: String, email : String , password : String , telephone : String) {
        self.name = name
        self.email = email
        self.password = password
        self.telephone = telephone
    }
    
    func updateProfile(email : String , password : String , newPassword  : String, telephone : String ) {
        self.email = email
        self.password = password
        self.newPassword = newPassword
        self.telephone = telephone
    }
    
    
}