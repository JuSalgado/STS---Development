//
//  ProjectColors.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class ProjectColors {
    
    static let navigationGreenColor : UIColor = UIColor(red:0.00, green:0.37, blue:0.41, alpha:1.0)
    static let contrastGreenColor : UIColor = UIColor(red:0.227, green:0.675, blue:0.627, alpha:1.0)
}