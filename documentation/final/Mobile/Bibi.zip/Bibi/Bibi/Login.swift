//
//  Login.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class Login : NSObject  {
    
    var companyCode : String = ""
    var email : String = ""
    var password : String = ""
    
    //init
    init(companyCode: String, email : String , password : String) {
        self.companyCode = companyCode
        self.email = email
        self.password = password
    
    }
}