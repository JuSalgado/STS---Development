//
//  DrivDestiniesTableCell.swift
//  Bibi
//
//  Created by Juliana Salgado on 12/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class DestiniesTableCell: UITableViewCell {

    @IBOutlet weak var destinyName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
