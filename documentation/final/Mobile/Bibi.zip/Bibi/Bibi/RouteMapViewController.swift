//
//  RouteMapViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 03/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import UIKit
import MapKit

class RouteMapViewController: UIViewController, AnnotationViewDataSource {
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    //Annotation
    var locationManager = CLLocationManager()
    
    let regionRadius: CLLocationDistance = 1000 //1000 meters (1 kilometer)
    
    var locations : [Location] = []
    
    //manage activity indicator
    var routeCounter = 0
    var succeesCounter = 0
    
    //Route
    var route : Route!
    
    var myRoute : MKRoute?
    
    var destiny : Destiny?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.startsListeningToServerFeedbackEvent()
    }
    
    //MARK : MAP INIT
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //Monitor if the internet connection changed
        self.includeNetworkObserver()
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.removeNetworkObserver()
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if self.destiny != nil{
            self.title = ("\(self.destiny!.originName)/\(self.destiny!.destinationName)")
            self.route = Route(destiny: destiny!)
            self.initialize()
        }else{
            self.showAlertController(1)
            self.title = "Trajeto"
            print("destiny nil")
        }
    }
    
    func initialize(){
        
        self.activityIndicator.hidesWhenStopped = true
        
        //initial route informations
        self.showRouteAnnotations()
        
        //center the map on the route
        mapView.setRegion(self.mapRegion(), animated: true)
        
    }
    
    
    
    //show the route for every peace
    func initRoute(){
        self.activityIndicator.startAnimating()
        self.routeCounter = locations.count-1
        
        for i in 0..<(locations.count-1){
            
            let originLocation = self.locations[i]
            let origin = MKPlacemark(coordinate: CLLocationCoordinate2DMake(originLocation.latitude, originLocation.longitude), addressDictionary: nil)
            
            //set the destination
            let destinationLocation = self.locations[i+1]
            let destination = MKPlacemark(coordinate: CLLocationCoordinate2DMake(destinationLocation.latitude, destinationLocation.longitude), addressDictionary: nil)
            
            self.generateRoute(origin, destination: destination)
            
        }
        
    }
    
    //put the locations in the correct order and show pins
    func showRouteAnnotations(){
        
        //origin location
        let origin : Location = Location(latitude:  Double(self.route.destiny.originLocation.latitude)
            , longitude: Double(self.route.destiny.originLocation.longitude)
            , timestamp: NSDate())
        
        //destination location
        let destination : Location = Location(latitude:  Double(self.route.destiny.destinationLocation.latitude)
            , longitude: Double(self.route.destiny.destinationLocation.longitude)
            , timestamp: NSDate())
        
        //first array object
        self.locations.append(origin)
        
        //SHOW PIN
        
        //show pin for origin
        showAnnotation(origin.latitude, longitude: origin.longitude , title : self.route.destiny.originName, index: -1)
        
        //passengers location
        let passengers = route.destiny.passengers
        for i in 0 ..< passengers.count {
            //followed array object
            let location : Location = Location(latitude:  Double(passengers[i].location.latitude)
                , longitude: Double(passengers[i].location.longitude)
                , timestamp: NSDate())
            
            if passengers[i].presence {
                
                self.locations.append(location)
            }
            
            
            //show pin for passenger
            showAnnotation(location.latitude, longitude: location.longitude, title : passengers[i].name, index : i)
        }
        
        //last array object
        self.locations.append(destination)
        
        //show pin for destination
        showAnnotation(destination.latitude, longitude: destination.longitude, title : self.route.destiny.destinationName, index: (self.locations.count-1))
        
    }
    
    //MARK: MAP MANAGER
    
    //generate the route for every piece
    func generateRoute(origin : MKPlacemark , destination : MKPlacemark ){
        
        //ask for direction
        let directionsRequest = MKDirectionsRequest()
        //set the directions
        directionsRequest.source = MKMapItem(placemark: origin)
        directionsRequest.destination = MKMapItem(placemark: destination)
        // request type auto
        directionsRequest.transportType = MKDirectionsTransportType.Automobile
        
        //direction request
        let directions = MKDirections(request: directionsRequest)
        
        //lets calculate the route
        directions.calculateDirectionsWithCompletionHandler { (response:MKDirectionsResponse?, error: NSError?) -> Void in
            if error == nil {
                self.succeesCounter++
                self.myRoute = response!.routes[0] as MKRoute
                self.mapView.addOverlay((self.myRoute?.polyline)!)
            }else{
                //internet connection error we already handle it
                let errorNetwork : Int = 1009
                if error?.code != errorNetwork {
                    print("Error GENERATE ROUTE:  \(error)")
                    //                    self.showAlertController(3)
                }
            }
            
            self.routeCounter--
            
            if self.routeCounter == 0 {
                print("route counter \(self.routeCounter)")
                self.activityIndicator.stopAnimating()
                
                //finished counting
                if self.succeesCounter != (self.locations.count-1){
                    self.showAlertController(3)
                    print("error success counter")
                }
                
            }
        }
    }
    
    
    //MARK: MAP Functions
    func mapRegion() -> MKCoordinateRegion{
        
        var region : MKCoordinateRegion = MKCoordinateRegion()
        let initialLocation = self.locations[0]
        
        var minLat = initialLocation.latitude
        var minLong = initialLocation.longitude
        var maxLat = initialLocation.latitude
        var maxLng = initialLocation.longitude
        
        for location: Location in self.locations {
            if location.latitude < minLat {
                minLat = location.latitude
            }
            if location.longitude < minLong {
                minLong = location.longitude
            }
            if location.latitude > maxLat {
                maxLat = location.latitude
            }
            if location.longitude > maxLng {
                maxLng = location.longitude
            }
        }
        
        region.center.latitude = (minLat + maxLat) / 2.0
        region.center.longitude = (minLong + maxLng) / 2.0
        region.span.latitudeDelta = (maxLat - minLat) * 1.1
        region.span.longitudeDelta = (maxLng - minLong) * 1.1
        
        return region
    }
    
    func showAnnotation(latitude : Double , longitude : Double , title: String , index : Int){
        // show artwork on map
        let stopPoint = StopPoint(title : title, index: index, coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude))
        mapView.addAnnotation(stopPoint)
        
    }
    
    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView,
        calloutAccessoryControlTapped control: UIControl) {
            let location = view.annotation as! StopPoint
            let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
            location.mapItem().openInMapsWithLaunchOptions(launchOptions)
    }
    
    func mapView(mapView: MKMapView, didSelectAnnotationView view: MKAnnotationView) {
        if let annotationView  = view as? DXAnnotationView{
            annotationView.showCalloutView()
            view.layer.zPosition =  5
        }
        
    }
    
    
    func mapView(mapView: MKMapView, didDeselectAnnotationView view: MKAnnotationView) {
        if let annotationView  = view as? DXAnnotationView{
            annotationView.hideCalloutView()
            view.layer.zPosition =  0
        }
        
    }
    
    //map design
    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
        
        let myLineRenderer = MKPolylineRenderer(polyline: (myRoute?.polyline)!)
        myLineRenderer.strokeColor = UIColor.blueColor()
        myLineRenderer.lineWidth = 3
        return myLineRenderer
    }
    
    func setAnnotationViewAccordingToLocation(annotation : StopPoint) -> UIImageView {
        
        var pinView: UIImageView? = nil
        
        //origin
        if annotation.index == -1 {
            pinView = UIImageView(image: UIImage(named: "originPin"))
        }else if annotation.index == (self.locations.count - 1) {
            //destination
            pinView = UIImageView(image: UIImage(named: "pinStopPoint"))
        }else if self.route.destiny.passengers[annotation.index].presence {
            //passenger that is going
            pinView = UIImageView(image: UIImage(named: "pinPassGoing"))
        }else {
            pinView = UIImageView(image: UIImage(named: "pinPassNotGoing"))
        }
        
        return pinView!
    }
    
    
    //MARK : - Data source and delegate methods
    
    func locationForIndex(annotationView: AnnotationView, index: Int) -> Location {
        
        return self.locations[index]
        
        
    }
    
    func nameForLocation(annotationView: AnnotationView, index: Int) -> String {
        
        if index == 0 {
            return self.route.destiny.originName
        }else if index == (self.locations.count - 1 ) {
            return self.route.destiny.destinationName
        }else {
            return self.route.destiny.passengers[index].name
        }
        
    }
}
