//
//  Location.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/09/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class Location: NSObject {
    
    var latitude: Double
    var longitude: Double
    var timestamp : NSDate?
    
    //init
    init(latitude: Double, longitude : Double , timestamp : NSDate?) {
        self.latitude = latitude
        self.longitude = longitude
        self.timestamp = timestamp
        
    }
}
