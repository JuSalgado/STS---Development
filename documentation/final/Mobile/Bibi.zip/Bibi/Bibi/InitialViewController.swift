//
//  InitialViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 23/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//


// TODO READ ME

//Caso o projeto não compile instalar cocoa pods no site
//https://cocoapods.org
//após instalado ir ao terminal e digitar os comandos
// cd PASTA_DO_PROJETO
// e em seguida o comando
// pod install
// depois é só reabrir o projeto pelo arquivo .xcworkspace
// Na Classe ServerManager alterar a variável serverURL para o IP da rede local


import UIKit

class InitialViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(animated: Bool) {
        if verifyDefaultsShouldConnect(){
            self.performSegueWithIdentifier("showLogin", sender: self)
        } else {
            ServerManager.user = User(companyCode: UserDefaultsLogin.companyCode!, name: UserDefaultsLogin.name!, email: UserDefaultsLogin.email!, password: UserDefaultsLogin.password!, telphone: UserDefaultsLogin.telephone!)
            
            if UserDefaultsLogin.isPassenger {
                
                self.performSegueWithIdentifier("loginPassenger", sender: self)
                
            }else{
                self.performSegueWithIdentifier("loginDriver", sender: self)
            }
            
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - User Defaults
    func verifyDefaultsShouldConnect() -> Bool{
        
        if UserDefaultsLogin.companyCode != nil && UserDefaultsLogin.email != nil && UserDefaultsLogin.name != nil && UserDefaultsLogin.password != nil && UserDefaultsLogin.telephone != nil  {
            
            //have already connected
            return false
            
        }
        
        return true
    }
    
}
