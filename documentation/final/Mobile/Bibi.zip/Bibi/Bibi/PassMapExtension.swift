//
//  MapExtension.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/09/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import Foundation
import MapKit


extension PassMapViewController: MKMapViewDelegate {
    
    // mapView(_:viewForAnnotation:) is the method that gets called for every annotation you add to the map (kind of like tableView(_:cellForRowAtIndexPath:) when working with table views), to return the view for each annotation.
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if let annotation = annotation as? StopPoint {
            var calloutView: UIView? = nil
            var pinView: UIImageView? = nil
            
            var annotationView: DXAnnotationView? = mapView.dequeueReusableAnnotationViewWithIdentifier(NSStringFromClass(DXAnnotationView.self)) as? DXAnnotationView
            
            if annotationView == nil {
                pinView = setAnnotationViewAccordingToLocation(annotation)
                
                calloutView = setCalloutViewAccordingToLocation(annotation)
                
                annotationView = DXAnnotationView(annotation: annotation, reuseIdentifier: NSStringFromClass(DXAnnotationView.self), pinView: pinView, calloutView: calloutView, settings: DXAnnotationSettings.defaultSettings())
            }
            else {
                pinView = annotationView!.pinView as? UIImageView
                pinView = UIImageView(image: UIImage(named: "car-blue-icon"))
            }
            
            return annotationView
        }
        return nil
    }
    
    func setCalloutViewAccordingToLocation(annotation : StopPoint) -> UIView {
        
        //first and last is a destiny
        if annotation.index == -1 {
            var calloutView: DestinyView? = nil
            calloutView = (NSBundle.mainBundle().loadNibNamed("destinyAnnotationView", owner: self, options: nil)).first as? DestinyView
            calloutView?.destinationName.text = self.route.destiny.originName
            calloutView?.destinationStartingHour.text = self.route.destiny.originStartHourString()
            calloutView?.destinationBackHour.text = self.route.destiny.originBackHourrString()
            calloutView?.dataSource = self
            calloutView?.index = 0
            return calloutView!
            
        }else if annotation.index == (self.locations.count - 1) {
            var calloutView: DestinyView? = nil
            calloutView = (NSBundle.mainBundle().loadNibNamed("destinyAnnotationView", owner: self, options: nil)).first as? DestinyView
            calloutView?.destinationName.text = self.route.destiny.destinationName
            calloutView?.destinationStartingHour.text = self.route.destiny.destinationStartHourString()
            calloutView?.destinationBackHour.text = self.route.destiny.destinationBackHourString()
            calloutView?.dataSource = self
            calloutView?.index = annotation.index
            return calloutView!
        }else if annotation.index == -10 {
            
            var calloutView: CurrentLocationAnnotatonView? = nil
            calloutView = (NSBundle.mainBundle().loadNibNamed("annotationCurrentLocation", owner: self, options: nil)).first as? CurrentLocationAnnotatonView
            return calloutView!
            
        }else {
            var calloutView: PassengerAnnotationView? = nil
            calloutView = (NSBundle.mainBundle().loadNibNamed("annotationPassengerView", owner: self, options: nil)).first as? PassengerAnnotationView
            calloutView?.dataSource = self
            calloutView?.index = annotation.index
            calloutView?.passengerName.text = self.route.destiny.passengers[annotation.index].name
            
            if let _ = self.route.destiny.passengers[annotation.index].hour{
                calloutView?.passengerHour.text = self.route.destiny.passengers[annotation.index].hourString()
            }else {
                calloutView?.passengerHour.text = "--:--"
            }
            return calloutView!
        }
    }
    
    
}