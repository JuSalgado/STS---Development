//
//  PassMapViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 10/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit
import MapKit

class PassMapViewController: RouteMapViewController {
    
    @IBOutlet weak var presenceSwitch: UISwitch!
    
    //driver location
    var driverLocations: [Location] = []
    
    //MARK : INIT
    
    override func initialize(){
        
        
        
        self.mapView.delegate = self
        
        
        self.getDriverLocations()
        
        self.presenceSwitch.enabled = false
        
        ServerManager.getPassengerPresence((self.destiny?.destinationName)!) { (presence, success, errorMessage) -> Void in
            //async
            
            dispatch_async(dispatch_get_main_queue()) {
                
                self.activityIndicator.stopAnimating()
                
                if !success {
                    EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                }else{
                    self.presenceSwitch.enabled = true
                    self.presenceSwitch.on = presence
                    
                }
            }
        }
        
        let timer : NSTimer = NSTimer(timeInterval: 180, target: self, selector: "getDriverLocations", userInfo: nil, repeats: true)
        timer.fire()
        
    }
    
    //server locations
    func getDriverLocations(){
        
        self.activityIndicator.startAnimating()
        
        ServerManager.getDriverLocations { (success, errorMessage, locations) -> Void in
            
            //async
            
            dispatch_async(dispatch_get_main_queue()) {
                
                self.activityIndicator.stopAnimating()
                
                if !success {
                    EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                }else{
                    self.driverLocations = locations
                    
                    super.initialize()
                    
                    //generate the route according to driver location
                    self.locations = self.driverLocations
                    
                    //generate route
                    self.initRoute()
                    
                }
            }
            
        }
        
    }
    
    
    override func showRouteAnnotations() {
        super.showRouteAnnotations()
        
        //show pin current location
        showAnnotation(self.driverLocations[self.driverLocations.count-1].latitude, longitude: self.driverLocations[self.driverLocations.count-1].longitude, title : "" , index: -10)
    }
    
    override func setAnnotationViewAccordingToLocation(annotation : StopPoint) -> UIImageView {
        
        var pinView: UIImageView? = nil
        
        //origin
        if annotation.index == -1 {
            pinView = UIImageView(image: UIImage(named: "originPin"))
        }else if  annotation.index == -10 {
            pinView = UIImageView(image: UIImage(named: "pinCurrentLocation"))
        }else if annotation.index == (self.locations.count - 1) {
            pinView = UIImageView(image: UIImage(named: "pinStopPoint"))
        }else if self.route.destiny.passengers[annotation.index].presence {
            
            //passenger that is going
            pinView = UIImageView(image: UIImage(named: "pinPassGoing"))
        }else{
            
            pinView = UIImageView(image: UIImage(named: "pinPassNotGoing"))
        }
        
        return pinView!
    }
    
    //MARK: ACTION
    
    @IBAction func presenceHasChanged(sender: AnyObject) {
        print("presence changed")
        
        var presence = false
        
        if presenceSwitch.on{
            presence = true
        }else {
            presence = false
        }
        self.activityIndicator.startAnimating()
        
        
        ServerManager.updatePresence(
            (self.destiny?.destinationName)! , passengerPresence: presence) { (success, errorMessage) -> Void in
                //async
                
                dispatch_async(dispatch_get_main_queue()) {
                    if self.isViewLoaded() && self.view.window != nil {
                        self.activityIndicator.stopAnimating()
                        
                    }
                    
                    if success {
                        self.presenceSwitch.on = presence
                    }else {
                        EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                    }
                    
                }
        }
        
    }
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let controller = (segue.destinationViewController as! UITableViewController) as! PassAboutMapTableViewController
        controller.destiny = self.destiny
        
    }
    
}
