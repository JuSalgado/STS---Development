//
//  passengerAnnotationView.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/09/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class PassengerAnnotationView: AnnotationView {

    @IBOutlet weak var passengerName: UILabel!
    @IBOutlet weak var passengerHour: UILabel!
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
}
