//
//  CurrentLocationAnnotationView.swift
//  Bibi
//
//  Created by Juliana Salgado on 22/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import Foundation

import UIKit

class CurrentLocationAnnotatonView: AnnotationView {

}