//
//  ServerManager.swift
//  Bibi
//
//  Created by Juliana Salgado on 14/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class ServerManager: NSObject {
    
    static var user : User?
    
    
    //TODO PARA TESTAR COMPLETAR COM O NUMERO IP DA REDE LOCAL
    static let serverURL = "http://192.168.0.100:9000"
    static let ERROR_MESSAGE : String = "Servidor temporariamente indisponível"
    //MARK: - Login
    
    
    //ok
    static func loginToServer(companyCode: String, username: String, password : String , completionHandler : (isPassenger: Bool, success: Bool, errorMessage: String?) -> Void) {
        
        var success : Bool = false
        var userIsPassenger : Bool = false
        var userCode : String?
        var userEmail : String?
        var userName : String?
        var userPassword : String?
        var userTelephone : String?
        var postErrorMessage : String?
        
        Alamofire.request(.POST, "\(self.serverURL)/iOSAuth", parameters: ["companyCode": companyCode , "username": username,"password": password])
            .responseJSON { response in
                //                print(response.request)  // original URL request
                //                print(response.response) // URL response
                //                print(response.data)     // server data
                //                print(response.result)   // result of response serialization
                
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            
                            if let codeCompany = json["id"].string {
                                
                                userCode = codeCompany
                            }
                            
                            if let name = json["name"].string{
                                
                                userName = name
                            }
                            if let email = json["email"].string{
                                userEmail = email
                            }
                            
                            if let password = json["password"].string{
                                userPassword = password
                            }
                            
                            if let telephone = json["telephone"].string{
                                userTelephone = telephone
                            }
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    if let isPassenger = json["isPassenger"].bool{
                                        
                                        userIsPassenger = isPassenger
                                        
                                    }
                                    success = true
                                }else{
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                        
                                        print("post error message \(postErrorMessage)")
                                    }
                                    success = false
                                }
                            }
                            
                            print("JSON: \(json)")
                            
                        }else {
                            success = false
                        }
                    case .Failure(let error):
                        print(error)
                        success = false
                    }
                    
                    if (userCode != nil) && (userEmail != nil ) && (userName != nil) && (userPassword != nil) && (userTelephone != nil)  {
                        
                        user = User(companyCode: userCode!, name: userName!, email: userEmail!, password: userPassword! , telphone: userTelephone!)
                        print(" user \(user?.name)")
                        completionHandler(isPassenger: userIsPassenger, success: success, errorMessage: postErrorMessage)
                        
                    }else{
                        //is passenger = true , success=true
                        completionHandler(isPassenger: userIsPassenger, success: false, errorMessage: postErrorMessage)
                        
                    }
                }else{
                    //is passenger = true , success=true
                    completionHandler(isPassenger: userIsPassenger, success: false, errorMessage: self.ERROR_MESSAGE )
                }
        }
        
        
        
    }
    
    //MARK: - Reset password
    
    //ok
    static func resetPassword(email : String , completionHandler : (success: Bool, errorMessage: String?) -> Void) {
        
        var success : Bool = false
        
        var postErrorMessage : String?
        
        
        Alamofire.request(.POST, "\(self.serverURL)/iOSResetPassword", parameters: ["email": email])
            .responseJSON { response in
                
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            print("JSON: \(json)")
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                        }else {
                            success = false
                        }
                    case .Failure(let error):
                        print(error)
                        success = false
                    }
                    
                    completionHandler(success: success, errorMessage: postErrorMessage)
                }else{
                    completionHandler(success: false, errorMessage: ERROR_MESSAGE)
                }
        }
        
        
    }
    
    //MARK: - General
    
    
    static func loadDestinies(companyCode : String , email : String , completionHandler : (destinies : [Destiny] , success: Bool, errorMessage: String? ) -> Void) {
        
        
        var success : Bool = false
        var postErrorMessage : String?
        var destinies : [Destiny] = [Destiny]()
        
        
        Alamofire.request(.GET, "\(self.serverURL)/iOSLoadDestinies")
            .responseJSON { response in
                if let _ = response.response {
                    
                    switch response.result {
                        
                    case .Success:
                        
                        if let value = response.result.value {
                            
                            let json = JSON(value)
                            
                            print("JSON: \(json)")
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                    
                                    for appDict in json["destinies"].arrayValue  {
                                        
                                        //ORIGIN
                                        
                                        let originName = appDict["origin"]["originName"].string
                                        
                                        let originLatitude = appDict["origin"]["originLocation"]["latitude"].double
                                        
                                        let originLongitude = appDict["origin"]["originLocation"]["longitude"].double
                                        
                                        var originTimeDate : NSDate? = nil
                                        if let originTime = appDict["origin"]["originLocation"]["timestamp"].string{
                                            originTimeDate = getDate(originTime)
                                        }
                                        
                                        let originStartHour = getDate(appDict["origin"]["originStartHour"].string!)
                                        
                                        var originBackHourDate : NSDate? = nil
                                        if let originBackHour = appDict["origin"]["originBackHour"].string {
                                            originBackHourDate = getDate(originBackHour)
                                        }
                                        
                                        
                                        //DESTINATION
                                        let destinationName = appDict["destinationName"].string
                                        
                                        let destinationLatitude = appDict["origin"]["destinationLocation"]["latitude"].double
                                        
                                        let destinationLongitude = appDict["origin"]["originLocation"]["longitude"].double
                                        
                                        let destinationTime = getDate(appDict["origin"]["originLocation"]["timestamp"].string!)
                                        
                                        let destinationStartHour = getDate(appDict["destinationStartHour"].string!)
                                        
                                        
                                        let destinationBackHour = getDate(appDict["destinationBackHour"].string!)
                                        
                                        
                                        let jsonPassengers = appDict["passengers"].arrayValue
                                        
                                        
                                        //PASSENGER
                                        
                                        var passengers : [Passenger] = [Passenger]()
                                        
                                        for passDict in jsonPassengers {
                                            
                                            let name = passDict["name"].string
                                            
                                            let presence = passDict["presence"].bool
                                            
                                            let latitude = passDict["passengers"]["location"]["latitude"].double
                                            
                                            
                                            let longitude = passDict["passengers"]["location"]["longitude"].double
                                            
                                            var timestamp : NSDate?
                                            if let time = passDict["passengers"]["location"]["timestamp"].string{
                                                timestamp = getDate(time)
                                            }
                                            
                                            
                                            
                                            let address = passDict["address"].string
                                            
                                            var passengerHour : NSDate? = nil
                                            if let hour = passDict["hour"].string {
                                                passengerHour = getDate(hour)
                                            }
                                            
                                            let passengerLocation : Location = Location(latitude: latitude!, longitude: longitude!, timestamp: timestamp)
                                            
                                            let passenger : Passenger = Passenger(name: name!, presence: presence!, location: passengerLocation, address: address!, hour: passengerHour!)
                                            passengers.append(passenger)
                                            
                                            
                                            
                                        }
                                        
                                        //DRIVER
                                        
                                        let driverName = appDict["driver"]["name"].string
                                        
                                        let driverTelphone = appDict["driver"]["telephone"].string
                                        
                                        //SWIFT OBJECTS
                                        let driver : Driver = Driver(name: driverName!, telphone: driverTelphone!)
                                        
                                        
                                        let destinationLocation : Location = Location(latitude: destinationLatitude!, longitude: destinationLongitude!, timestamp: destinationTime)
                                        
                                        let originLocation : Location = Location(latitude: originLatitude!, longitude: originLongitude!, timestamp: originTimeDate)
                                        
                                        
                                        let destiny : Destiny = Destiny(originName: originName!, originLocation: originLocation, originStartHour: originStartHour, originBackHour: originBackHourDate!, destinationName: destinationName!, destinationLocation: destinationLocation, destinationStartHour: destinationStartHour, destinationBackHour: destinationBackHour, passengers: passengers, driver: driver)
                                        
                                        
                                        destinies.append(destiny)
                                        
                                        
                                    }
                                    //                                    }
                                    
                                    
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                        }
                    case .Failure(let error):
                        success = false
                        print(error)
                    }
                    
                    
                    completionHandler(destinies: destinies, success: success, errorMessage: postErrorMessage)
                } else{
                    completionHandler(destinies: destinies, success: success , errorMessage: self.ERROR_MESSAGE)
                }
        }
        
    }
    
    //MARK: - Driver
    
    
    //OK
    static func sendDriverLocationsToServer(driverLocations: [Location] , completionHandler :(success: Bool, errorMessage: String?) -> Void) {
        
        var success : Bool = false
        var postErrorMessage : String?
        
        var jsonDictArray: [AnyObject] = []
        
        for i in 0 ..< driverLocations.count{
            let formatter = NSDateFormatter()
            formatter.timeStyle = .ShortStyle
            
            let date = formatter.stringFromDate( driverLocations[i].timestamp!)
            
            let dict =
            [
                "latitude": driverLocations[i].latitude,
                "longitude": driverLocations[i].longitude,
                "timestamp": date
            ]
            jsonDictArray.append(dict)
        }
        
        do{
            let data = try NSJSONSerialization.dataWithJSONObject(jsonDictArray, options: .PrettyPrinted)
            
            Alamofire.request(.POST, "\(self.serverURL)/iOSSendDriverLocations", parameters: ["locations" : data])
                .responseJSON { response in
                    
                    
                    if let _ = response.response {
                        switch response.result {
                        case .Success:
                            if let value = response.result.value {
                                
                                let json = JSON(value)
                                print("JSON: \(json)")
                                
                                if let status = json["status"].bool {
                                    
                                    if status {
                                        success = true
                                    }else{
                                        success = false
                                        if let errorMessage = json["errorMessage"].string{
                                            
                                            postErrorMessage = errorMessage
                                        }
                                    }
                                }
                            }
                        case .Failure(let error):
                            print(error)
                        }
                        
                        completionHandler(success: success, errorMessage: postErrorMessage)
                    }else{
                        completionHandler(success: success, errorMessage: self.ERROR_MESSAGE)
                    }
            }
            
        }catch let error as NSError{
            print(error)
        }
        
    }
    
    //ok
    static func driverUpdatedPassengerPresence(destinyName : String ,passengerName: String, passengerAddress: String,passengerPresence: Bool , completionHandler :(success: Bool, errorMessage: String?) -> Void){
        
        var success : Bool = false
        var postErrorMessage : String?
        
        Alamofire.request(.POST, "\(self.serverURL)/iOSDriverUpdatedPresence", parameters: ["destinationName" : destinyName , "driverEmail": (user?.email)!,"passengerName": passengerName , "passengerAddress":passengerAddress,"passengerPresence":passengerPresence])
            .responseJSON { response in
                
                
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            
                            print("JSON: \(json)")
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                        }
                    case .Failure(let error):
                        print(error)
                    }
                    
                    //is success = true
                    completionHandler(success: success, errorMessage: postErrorMessage)
                }else {
                    completionHandler(success: success, errorMessage: self.ERROR_MESSAGE)
                }
        }
        
        
    }
    
    //MARK: - Passenger
    
    //ok
    static func getPassengerPresence (destiny : String , completionHandler : (presence : Bool , success: Bool, errorMessage: String? ) -> Void) {
        
        var success : Bool = false
        
        var postErrorMessage : String?
        
        var presence : Bool = true
        
        Alamofire.request(.GET, "\(self.serverURL)/iOSGetPassengerPresence", parameters: ["email": (ServerManager.user?.email)! , "destinationName": destiny])
            .responseJSON { response in
                
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            print("JSON: \(json)")
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                    if let pasPresence = json["presence"].bool{
                                        presence = pasPresence
                                    }else{
                                        success = false
                                    }
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                        }else {
                            success = false
                        }
                    case .Failure(let error):
                        print(error)
                        success = false
                    }
                    
                    completionHandler(presence : presence , success: success, errorMessage: postErrorMessage)
                }else{
                    completionHandler(presence: presence, success : false ,errorMessage: ERROR_MESSAGE)
                }
        }
        
        
        
    }
    
    static func getDriverLocations(completionHandler :(success: Bool, errorMessage: String? , locations : [Location]) -> Void){
        var success : Bool = false
        var postErrorMessage : String?
        var locations : [Location] = []
        
        Alamofire.request(.GET, "\(self.serverURL)/iOSGetDriverLocations")
            .responseJSON { response in
                if let _ = response.response {
                    
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            
                            let json = JSON(value)
                            print("JSON: \(json)")
                            
                            
                            if let appArray = json["locations"].array {
                                
                                
                                for appDict in appArray {
                                    
                                    
                                    var timeLocation : NSDate? = nil
                                    if let timestamp = appDict["timestamp"].string {
                                        timeLocation = getDate(timestamp)
                                    }
                                    
                                    let longitude = appDict["longitude"].double
                                    let latitude = appDict["latitude"].double
                                    
                                    let location = Location(latitude: latitude!, longitude: longitude!, timestamp: timeLocation)
                                    locations.append(location)
                                }
                            }
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                            
                        }
                    case .Failure(let error):
                        success = false
                        print(error)
                    }
                    
                    completionHandler(success: success, errorMessage: postErrorMessage, locations: locations)
                }else {
                    completionHandler(success: success, errorMessage: self.ERROR_MESSAGE, locations: locations)
                }
        }
        
    }
    
    //ok
    static func updatePassengerEmail(email : String , completionHandler :(success: Bool, errorMessage: String?) -> Void){
        
        var success : Bool = false
        var postErrorMessage : String?
        
        
        Alamofire.request(.POST, "\(self.serverURL)/iOSUpdatePassengerEmail", parameters: ["currentEmail": user!.email , "email" : email])
            .responseJSON { response in
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            
                            print("JSON: \(json)")
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                    self.user?.email = email
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                        }
                    case .Failure(let error):
                        success = false
                        print(error)
                    }
                    
                    completionHandler(success: success, errorMessage: postErrorMessage)
                }else{
                    completionHandler(success: success, errorMessage: self.ERROR_MESSAGE)
                }
        }
        
        
    }
    
    //ok
    static func updatePassengerTelphone(telephone : String , completionHandler :(success: Bool, errorMessage: String?) -> Void) {
        
        
        var success : Bool = false
        var postErrorMessage : String?
        
        Alamofire.request(.POST, "\(self.serverURL)/iOSUpdatePassengerTelephone", parameters: ["email": user!.email , "telephone" : telephone])
            .responseJSON { response in
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                    
                                    self.user?.telphone = telephone
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                            
                            print("JSON: \(json)")
                        }
                    case .Failure(let error):
                        success = false
                        print(error)
                    }
                    
                    completionHandler(success: success, errorMessage: postErrorMessage)
                }else{
                    completionHandler(success: success, errorMessage: self.ERROR_MESSAGE)
                }
        }
        
    }
    
    //ok
    static func updatePassengerPassword(password : String , newPassword : String , completionHandler :(success: Bool, errorMessage: String?) -> Void){
        
        
        var success : Bool = false
        var postErrorMessage : String?
        
        Alamofire.request(.POST, "\(self.serverURL)/iOSUpdatePassengerPassword", parameters: ["email": user!.email , "currentPassword" : password , "password" : newPassword])
            .responseJSON { response in
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                    
                                    self.user?.password = newPassword
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                            
                            print("JSON: \(json)")
                        }
                    case .Failure(let error):
                        print(error)
                        success = false
                    }
                    completionHandler(success: success, errorMessage: postErrorMessage)
                }else{
                    completionHandler(success: success, errorMessage: self.ERROR_MESSAGE)
                }
        }
    }
    
    //ok
    static func updatePresence(destinationName : String ,passengerPresence: Bool , completionHandler :(success: Bool, errorMessage: String?) -> Void){
        
        var success : Bool = false
        var postErrorMessage : String?
        
        Alamofire.request(.POST, "\(self.serverURL)/iOSUpdatePresence", parameters: ["passengerPresence": passengerPresence , "email":user!.email , "destinationName" : destinationName])
            .responseJSON { response in
                if let _ = response.response {
                    switch response.result {
                    case .Success:
                        if let value = response.result.value {
                            let json = JSON(value)
                            
                            print("JSON: \(json)")
                            
                            if let status = json["status"].bool {
                                
                                if status {
                                    success = true
                                }else{
                                    success = false
                                    if let errorMessage = json["errorMessage"].string{
                                        
                                        postErrorMessage = errorMessage
                                    }
                                }
                            }
                        }
                    case .Failure(let error):
                        print(error)
                        success = false
                    }
                    
                    completionHandler(success: success, errorMessage: postErrorMessage)
                }else{
                    completionHandler(success: success, errorMessage: self.ERROR_MESSAGE)
                }
        }
        
    }
    
    //MARK : Helpers Functions
    static func getDate(dateString:NSString) -> NSDate{
        
        
        let dateFormatter = NSDateFormatter()
        
        if(dateString.length == 19)
        {
            dateFormatter.dateFormat = "YYYY-MM-dd'T'HH:mm:ss" //This is the format returned by .Net website
        }
        else if(dateString.length == 21)
        {
            dateFormatter.dateFormat = "YYYY-MM-dd'T'HH:mm:ss.S" //This is the format returned by .Net website
        }
        else if(dateString.length == 22)
        {
            dateFormatter.dateFormat = "YYYY-MM-dd'T'HH:mm:ss.SS" //This is the format returned by .Net website
        }
        else if(dateString.length == 23)
        {
            dateFormatter.dateFormat = "YYYY-MM-dd'T'HH:mm:ss.SSS"
        }
        
        let date = dateFormatter.dateFromString(dateString as String)
        
        
        return date!;
    }
    
    static func JSONStringify(value: AnyObject,prettyPrinted:Bool = false) -> String{
        
        let options = prettyPrinted ? NSJSONWritingOptions.PrettyPrinted : NSJSONWritingOptions(rawValue: 0)
        
        
        if NSJSONSerialization.isValidJSONObject(value) {
            
            do{
                let data = try NSJSONSerialization.dataWithJSONObject(value, options: options)
                if let string = NSString(data: data, encoding: NSUTF8StringEncoding) {
                    return string as String
                }
            }catch {
                
                print("error")
                //Access error here
            }
            
        }
        return ""
        
    }
    
}