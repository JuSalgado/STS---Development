//
//  driverAnnotationView.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/09/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

@objc protocol DriverViewDataSource : NSObjectProtocol {
    func presenceHasChanged(driverAnnotationView: DriverAnnotationView, index : Int , presence : Bool)
}
class DriverAnnotationView: AnnotationView {
    
    
    var passengerPresence : Bool = true
    
    @IBOutlet weak var driverDataSource : AnyObject!
    
    @IBOutlet weak var passengerName: UILabel!
    @IBOutlet weak var passengerAddress: UILabel!
    @IBOutlet weak var passengerSwicth: UISwitch!
    
    @IBAction func presenceChanged(sender: AnyObject) {
        self.passengerPresence = !passengerPresence
        
        if self.driverDataSource is DriverViewDataSource{
            
            //it was able to change the presence on the server
            self.dataSource.presenceHasChanged!(self, index: self.index, presence: self.passengerPresence)
            print("changed")
            
        }
    }
    
}
