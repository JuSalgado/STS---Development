//
//  User.swift
//  Bibi
//
//  Created by Juliana Salgado on 14/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class User:NSObject{

    var companyCode : String = ""
    var email : String = ""
    var password : String = ""
    var name : String = ""
    var telphone : String = ""
    
    //init
    init(companyCode: String, name : String , email : String , password : String , telphone : String) {
        self.name = name
        self.companyCode = companyCode
        self.email = email
        self.password = password
        self.telphone = telphone
        
    }

}