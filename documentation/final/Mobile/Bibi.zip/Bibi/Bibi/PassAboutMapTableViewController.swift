//
//  PassAboutMapTableViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 10/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class PassAboutMapTableViewController: UITableViewController {
    
    
    //Going
    @IBOutlet weak var goingName: UILabel!
    @IBOutlet weak var goingStartHour: UILabel!
    @IBOutlet weak var goingArriveHour: UILabel!
    
    //Back
    @IBOutlet weak var backName: UILabel!
    @IBOutlet weak var backStartHour: UILabel!
    @IBOutlet weak var backArriveHour: UILabel!
    
    @IBOutlet weak var driverName: UILabel!
    @IBOutlet weak var driverTelphone: UILabel!
    
    let cellReuseIdentifier = "passenger-cell"
    
    var destiny : Destiny?
    
    //MARK : INIT
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.startsListeningToServerFeedbackEvent()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //Monitor if the internet connection changed
        self.includeNetworkObserver()
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.removeNetworkObserver()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if self.destiny != nil {
            self.initialize()
            self.title = ("\(self.destiny!.originName)\(self.destiny!.destinationName)")
        }else {
            self.title = "Trajeto"
            self.showAlertController(1)
        }
        
    }
    
    //MARK: - Initialize
    
    //init static content
    func initialize(){
        
        
        //going
        
        self.goingName.text = self.destiny!.originName
        self.goingStartHour.text = self.dateFormat(self.destiny!.originStartHour)
        self.goingArriveHour.text =  self.dateFormat(self.destiny!.originBackHour)
        
        //Back
        
        self.backName.text = self.destiny!.destinationName
        
        self.backStartHour.text = self.dateFormat(self.destiny!.destinationStartHour)
        self.backArriveHour.text = self.dateFormat(self.destiny!.destinationBackHour)
        
        //Driver
        
        self.driverName.text = self.destiny?.driver.name
        self.driverTelphone.text = self.destiny?.driver.telphone
        
    }
    
    // MARK: - Table view data source
    
    //setup the header design
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel!.textColor = UIColor(red:0.00, green:0.37, blue:0.41, alpha:1.0)
        let font = UIFont(name: "Kohinoor Devanagari", size: 16.0)
        headerView.textLabel!.font = font!
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 3
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
}
