//
//  DrivDestiniesTableViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 10/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class DrivDestiniesTableViewController: DestiniesViewController {
    
    let showDetailSegue = "showDetail"
    
    // strong grey
    let textSelectedColor : UIColor = UIColor(red:0.88, green:0.86, blue:0.85, alpha:1.0)
    
    //grey
    let textNormalColor : UIColor = UIColor(red:0.80, green:0.80, blue:0.80, alpha:1.0)
    
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let actionTitle = "info"
        let more = UITableViewRowAction(style: .Normal, title: actionTitle) { action, index in
            self.infoTapped()
        }
        more.backgroundColor = ProjectColors.contrastGreenColor
        self.destinySelected = self.destinies[indexPath.row]
        return [more]
        
    }
    
    //MARK: ACTION
    
    @IBAction func disconnect(sender: AnyObject) {
        UserDefaultsLogin.deleteDefaultsDisconnect()
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func infoTapped(){
        self.performSegueWithIdentifier(self.showDetailSegue, sender: nil)
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
        
        if segue.identifier == self.showDetailSegue {
            // Put the destination view controller in a variable
            let controller = (segue.destinationViewController as! UITableViewController) as! DrivAboutMapTableViewController
            controller.destiny = self.destinySelected
        }else{
            // Put the destination view controller in a variable
            let controller = (segue.destinationViewController) as! DrivMapViewController
            controller.destiny = self.destinySelected
        }
    }
    
}
