//
//  DestiniesViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class DestiniesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    let cellReuseIdentifier = "destinies-cell"
    
    var destinies : [Destiny] = [Destiny]()
    
    var destinySelected : Destiny?
    
    
    // MARK: - INIT
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.startsListeningToServerFeedbackEvent()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //Monitor if the internet connection changed
        self.includeNetworkObserver()
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.removeNetworkObserver()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        self.activityIndicator.hidesWhenStopped = true
        
        self.loadData()
        
        
    }
    
    //MARK : server
    func loadData() {
        
        self.activityIndicator.startAnimating()
        
        ServerManager.loadDestinies((ServerManager.user?.companyCode)!, email: (ServerManager.user?.email)!) { (destinies, success, errorMessage) -> Void in
            //async
            
            dispatch_async(dispatch_get_main_queue()) {
                
                if self.isViewLoaded() && self.view.window != nil {
                    self.activityIndicator.stopAnimating()
                }
                
                if !success {
                    EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                }else {
                    self.destinies = destinies
                }
            }
        }
        
    }
    
    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return self.destinies.count
    }
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(cellReuseIdentifier, forIndexPath: indexPath) as! DestiniesTableCell
        
        let destiny = destinies[indexPath.row]
        
        cell.destinyName.text = "\(destiny.originName)/\(destiny.destinationName)"
        
        return cell
    }
    
    func tableView(tableView: UITableView, willSelectRowAtIndexPath indexPath: NSIndexPath) -> NSIndexPath? {
        self.destinySelected = self.destinies[indexPath.row]
        return indexPath
    }
}
