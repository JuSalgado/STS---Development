//
//  DrivAboutMapTableViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 10/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class DrivAboutMapTableViewController: UITableViewController {
    
    //Going
    @IBOutlet weak var goingName: UILabel!
    @IBOutlet weak var goingStartHour: UILabel!
    @IBOutlet weak var goingArriveHour: UILabel!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    //Back
    @IBOutlet weak var backName: UILabel!
    @IBOutlet weak var backStartHour: UILabel!
    @IBOutlet weak var backArriveHour: UILabel!
    
    var destiny : Destiny?
    
    //MARK : INIT
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.startsListeningToServerFeedbackEvent()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if self.destiny != nil {
            
            self.title = ("\(self.destiny!.originName)/\(self.destiny!.destinationName)")
            self.initialize()
            
        }else{
            self.title = "Trajeto"
            self.showAlertController(-1)
            print("destiny nil")
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    //MARK: - Initialize
    
    func initialize(){
        
        //going
        
        self.goingName.text = self.destiny!.originName
        self.goingStartHour.text = self.dateFormat(self.destiny!.originStartHour)
        self.goingArriveHour.text =  self.dateFormat(self.destiny!.originBackHour)
        
        //Back
        
        self.backName.text = self.destiny!.destinationName
        
        self.backStartHour.text = self.dateFormat(self.destiny!.destinationStartHour)
        self.backArriveHour.text = self.dateFormat(self.destiny!.destinationBackHour)
        
    }
    
    
    
}
