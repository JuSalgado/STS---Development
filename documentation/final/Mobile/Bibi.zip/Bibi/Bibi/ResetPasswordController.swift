//
//  ResetPasswordController.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/09/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import UIKit
import SwiftValidator

class ResetPasswordController: UIViewController , ValidationDelegate,  UITextFieldDelegate{
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var confirmEmail: UITextField!
    @IBOutlet weak var confirmEmailErrorLabel: UILabel!
    
    @IBOutlet weak var emailErrorLabel: UILabel!
    @IBOutlet weak var email: UITextField!
    
    
    // MARK: - INIT
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //Monitor if the internet connection changed
        self.includeNetworkObserver()
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.removeNetworkObserver()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        self.activityIndicator.hidesWhenStopped = true
        
    }
    
    //cocoa pods validator
    let validator = Validator()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.email.delegate = self
        self.confirmEmail.delegate = self
        self.setValidation()
        
        self.startsListeningToServerFeedbackEvent()
    }
    
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func setValidation(){
        
        validator.styleTransformers(success:{ (validationRule) -> Void in
            // clear error label
            validationRule.errorLabel?.hidden = true
            validationRule.errorLabel?.text = ""
            validationRule.textField.layer.borderColor = ProjectColors.navigationGreenColor.CGColor
            validationRule.textField.layer.borderWidth = 0.5
            
            }, error:{ (validationError) -> Void in
                validationError.errorLabel?.hidden = false
                validationError.errorLabel?.text = validationError.errorMessage
                validationError.textField.layer.borderColor = UIColor.redColor().CGColor
                validationError.textField.layer.borderWidth = 1.0
        })
        
        validator.registerField(email, errorLabel: emailErrorLabel, rules: [RequiredRule(message: "Campo obrigatório"), EmailRule(message: "Email inválido")])
        validator.registerField(confirmEmail, errorLabel: confirmEmailErrorLabel, rules: [RequiredRule(message: "Campo obrigatório"), ConfirmationRule(confirmField: email, message: "Os emails não correspondem")])
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: ACTION
    @IBAction func resetPassword(sender: AnyObject) {
        validator.validate(self)
        
    }
    
    //MARK: TEXTFIELD DELEGATE
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    // MARK: ValidationDelegate Methods
    
    func validationSuccessful() {
        print("Validation Success!")
        
        self.activityIndicator.startAnimating()
        //success
        
        ServerManager.resetPassword(self.email.text!) {(success, errorMessage) -> Void in
            //
            
            //async
            
            dispatch_async(dispatch_get_main_queue()) {
                
                if self.isViewLoaded() && self.view.window != nil {
                    self.activityIndicator.stopAnimating()
                }
                
                EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
            }
        }
    }
    func validationFailed(errors:[UITextField:ValidationError]) {
        print("Validation FAILED!")
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
