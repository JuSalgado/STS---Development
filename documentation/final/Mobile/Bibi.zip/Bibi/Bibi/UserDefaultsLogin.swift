//
//  UserDefaultsLogin.swift
//  Bibi
//
//  Created by Juliana Salgado on 21/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class UserDefaultsLogin : NSObject {
    
    //USER DEFAULTS FOR SESSION
    
    static let defaults = NSUserDefaults.standardUserDefaults()
    
    // User Defaults variable identifiers
    static let COMPANY_CODE = "companyCode"
    static let EMAIL = "email"
    static let PASSWORD = "password"
    static let NAME = "name"
    static let TELEPHONE = "telephone"
    static let IS_PASSENGER = "isPassenger"
    static let PRESENCE = "presence"
    
    
    // Defines companyCode
    static var companyCode : String?
        {
        get {
        if let id = defaults.objectForKey(COMPANY_CODE) as? String
    {
        return id
        }
        return nil
        }
        set(companyCode) {
            defaults.setValue(companyCode, forKey: COMPANY_CODE)
        }
    }
    
    
    // Defines email
    static var email : String?
        {
        get {
        if let email = defaults.objectForKey(EMAIL) as? String
    {
        return email
        }
        return nil
        }
        set(email) {
            defaults.setValue(email, forKey: EMAIL)
        }
    }
    
    // Defines password
    static var password : String?
        {
        get {
        if let password = defaults.objectForKey(PASSWORD) as? String
    {
        return password
        }
        return nil
        }
        set(password) {
            defaults.setValue(password, forKey: PASSWORD)
        }
    }
    
    // Defines name
    static var name : String?
        {
        get {
        if let name = defaults.objectForKey(NAME) as? String
    {
        return name
        }
        return nil
        }
        set(name) {
            defaults.setValue(name, forKey: NAME)
        }
    }
    
    // Defines telephone
    static var telephone : String?
        {
        get {
        if let telephone = defaults.objectForKey(TELEPHONE) as? String
    {
        return telephone
        }
        return nil
        }
        set(telephone) {
            defaults.setValue(telephone, forKey: TELEPHONE)
        }
    }
    
    
    // Defines isPassenger
    static var isPassenger : Bool
        {
        get {
        if let isPassenger = defaults.objectForKey(IS_PASSENGER) as? Bool
    {
        return isPassenger
        }
        return false
        }
        set(isPassenger) {
            defaults.setBool(isPassenger, forKey: IS_PASSENGER)
        }
    }
    
    // Defines PRESENCE
    static var presence : Bool
        {
        get {
        if let presence = defaults.objectForKey(PRESENCE) as? Bool
    {
        return presence
        }
        return false
        }
        set(presence) {
            defaults.setBool(isPassenger, forKey: PRESENCE)
        }
    }
    
    static func deleteDefaultsDisconnect(){
        defaults.removeObjectForKey(COMPANY_CODE)
        defaults.removeObjectForKey(EMAIL)
        defaults.removeObjectForKey(NAME)
        defaults.removeObjectForKey(PASSWORD)
        defaults.removeObjectForKey(TELEPHONE)
        defaults.removeObjectForKey(IS_PASSENGER)
        defaults.removeObjectForKey(PRESENCE)
    }
    
    
    
}