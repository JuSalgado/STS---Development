//
//  Route.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class Route: NSObject {
    
    //first and last
    var destiny : Destiny
    
    init(destiny : Destiny){
        self.destiny = destiny
    }
}