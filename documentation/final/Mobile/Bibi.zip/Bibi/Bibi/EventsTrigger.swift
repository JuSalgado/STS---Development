//
//  EventsTrigger.swift
//  Bibi
//
//  Created by Juliana Salgado on 23/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class EventsTrigger {
    
    static let events: EventManager = EventManager()
    
    static func triggerServerFeedbackEvent(success: Bool, errorMessage: String?) {
        if !success {
            if let message = errorMessage{
                events.trigger("serverFeedbackMessage", information: message)
            }else{
                events.trigger("serverFeedbackCode")
            }
        }
    }
}