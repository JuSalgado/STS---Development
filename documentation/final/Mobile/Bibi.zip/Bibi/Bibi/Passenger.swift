//
//  Passenger.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import Foundation


class Passenger : NSObject {
    
    var name : String = ""
    var presence : Bool = true
    var location : Location
    var hour : NSDate?
    var address : String = ""
    
    
    //date formatter
    var formatter : NSDateFormatter = NSDateFormatter()
    
    //init
    init(name: String, presence : Bool , location : Location ,address : String , hour : NSDate) {
        self.name = name
        self.presence = presence
        self.location = location
        self.address = address
        self.hour = hour
    }
    
    func driverUpdatesPassengerStatus(presence : Bool){
    
        self.presence = presence
        
        //deal server
    }
    
    func passengerUpdatesStatus(presence : Bool){
    
        self.presence = presence
        
        //deal server
    }
    
    func dateToHourString(date: NSDate) -> String {
        formatter.dateFormat = "HH:mm"
        return formatter.stringFromDate(date)
    }
    
    func hourString() -> String {
        return dateToHourString(hour!)
    }
}