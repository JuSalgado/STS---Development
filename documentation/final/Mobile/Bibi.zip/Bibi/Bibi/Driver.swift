//
//  Driver.swift
//  Bibi
//
//  Created by Juliana Salgado on 24/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import Foundation

class Driver: NSObject {
    
    var name : String = ""
    var telphone : String = ""
    
    //init
    init(name: String, telphone: String) {
        self.name = name
        self.telphone = telphone
    }
}