//
//  DestinyView.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/09/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit


class DestinyView: AnnotationView {
    
    
    @IBOutlet weak var destinationName: UILabel!
    @IBOutlet weak var destinationStartingHour: UILabel!
    @IBOutlet weak var destinationBackHour: UILabel!
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
    // Drawing code
    }
    */
    
}
