//
//  LocationManager.swift
//  Bibi
//
//  Created by Juliana Salgado on 15/09/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit
import CoreLocation

@objc protocol LocationManagerDelegate {
    optional func locationManager(locationManager: LocationManager, didUpdateUserLocation location: Location);
}

class LocationManager: NSObject, CLLocationManagerDelegate {
    
    static let sharedInstance = LocationManager()
    
    private var coreLocationManager = CLLocationManager()
    
    var searchingDistanceInKilometers: Float = 30
    
    var delegate: LocationManagerDelegate?
    
    func startTrackingLocation() {
        coreLocationManager.delegate = self
        coreLocationManager.distanceFilter = 1000
        coreLocationManager.desiredAccuracy = kCLLocationAccuracyKilometer
        coreLocationManager.requestWhenInUseAuthorization()
        coreLocationManager.startUpdatingLocation()
        coreLocationManager.startMonitoringSignificantLocationChanges()
    }
    
    func currentCLLocation() -> CLLocation? {
        let location: CLLocation? = coreLocationManager.location
        return location
    }
    
    func currentLocation() -> Location? {
        return Location(latitude: Double(coreLocationManager.location!.coordinate.latitude), longitude: Double(coreLocationManager.location!.coordinate.longitude) , timestamp: coreLocationManager.location!.timestamp)
    }
    
    func locationWithCLLocation(location: CLLocation) -> Location {
        return Location(latitude: Double(location.coordinate.latitude), longitude: Double(location.coordinate.longitude) , timestamp: location.timestamp)
    }
    
    // MARK: CLLocationManagerDelegate methods
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
      
        if locations.count > 0 {
            let newLocation: CLLocation = locations[0] 
            
            let location = locationWithCLLocation(newLocation)

            delegate?.locationManager?(self, didUpdateUserLocation: location)
        }
    }

    
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        if status == CLAuthorizationStatus.AuthorizedWhenInUse || status == CLAuthorizationStatus.AuthorizedAlways {
            coreLocationManager.startUpdatingLocation()
            coreLocationManager.startMonitoringSignificantLocationChanges()
        } else if status == CLAuthorizationStatus.Denied {
            coreLocationManager.stopUpdatingLocation()
            coreLocationManager.stopMonitoringSignificantLocationChanges()
        }
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print(error)
    }
    
    func kilometersWithMeters(meters: Int) -> Int {
        return Int(round(Double(meters)/Double(1000)))
    }
    
}

