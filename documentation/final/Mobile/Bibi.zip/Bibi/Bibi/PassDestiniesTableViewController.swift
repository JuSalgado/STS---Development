//
//  PassDestiniesTableViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 12/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//

import UIKit

class PassDestiniesTableViewController: DestiniesViewController {
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showMap"{
            let controller = (segue.destinationViewController ) as! PassMapViewController
            controller.destiny = destinySelected
        }
    }
    
    
}
