//
//  AnnotationView.swift
//  Bibi
//
//  Created by Juliana Salgado on 09/11/15.
//  Copyright © 2015 Juliana Salgado. All rights reserved.
//

import UIKit

@objc protocol AnnotationViewDataSource : NSObjectProtocol {
    
    func locationForIndex(annotationView : AnnotationView, index : Int) -> Location
    func nameForLocation(annotationView : AnnotationView, index : Int) -> String
}

class AnnotationView : UIView {

    var index : Int = 0
    
    @IBOutlet weak var dataSource : AnyObject!

    @IBAction func infoClicked(sender: AnyObject) {
        
        
        if dataSource is AnnotationViewDataSource{
            
            let location: Location = dataSource.locationForIndex(self, index: self.index)
            let name : String = dataSource.nameForLocation(self,index: self.index)
            //-23.085279, longitude: -46.953530,
            let url : NSURL = NSURL(string: "http://maps.apple.com/?q=\(name)&ll=\(location.latitude),\(location.longitude)")!
            UIApplication.sharedApplication().openURL(url)
            
        }
    }
    
 
}