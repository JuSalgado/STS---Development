//
//  LoginViewController.swift
//  Bibi
//
//  Created by Juliana Salgado on 10/08/15.
//  Copyright (c) 2015 Juliana Salgado. All rights reserved.
//


// TODO READ ME

//Caso o projeto não compile instalar cocoa pods no site
//https://cocoapods.org
//após instalado ir ao terminal e digitar os comandos
// cd PASTA_DO_PROJETO
// e em seguida o comando
// pod install
// depois é só reabrir o projeto pelo arquivo .xcworkspace
// Na Classe ServerManager alterar a variável serverURL para o IP da rede local

import UIKit
import SwiftValidator
import NotificationCenter

class LoginViewController: UIViewController, ValidationDelegate ,UITextFieldDelegate {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var passwordErrorLabel: UILabel!
    
    
    @IBOutlet weak var user: UITextField!
    @IBOutlet weak var userErrorLabel: UILabel!
    
    @IBOutlet weak var companyCodeErrorLabel: UILabel!
    @IBOutlet weak var companyCode: UITextField!
    
    
    //segues
    let showPassengerSegue = "passengerController"
    let showDriverSegue = "driverController"
    
    //cocoa pods validator
    let validator = Validator()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.password.delegate = self
        self.user.delegate = self
        self.companyCode.delegate = self
        self.setValidation()
        
        self.startsListeningToServerFeedbackEvent()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //Monitor if the internet connection changed
        self.includeNetworkObserver()
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.removeNetworkObserver()
    }
    
    // MARK: - INIT
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        self.activityIndicator.hidesWhenStopped = true
        
    }
    
    func setValidation(){
        
        validator.styleTransformers(success:{ (validationRule) -> Void in
            // clear error label
            validationRule.errorLabel?.hidden = true
            validationRule.errorLabel?.text = ""
            validationRule.textField.layer.borderColor = ProjectColors.navigationGreenColor.CGColor
            validationRule.textField.layer.borderWidth = 0.5
            
            }, error:{ (validationError) -> Void in
                validationError.errorLabel?.hidden = false
                validationError.errorLabel?.text = validationError.errorMessage
                validationError.textField.layer.borderColor = UIColor.redColor().CGColor
                validationError.textField.layer.borderWidth = 1.0
        })
        
        validator.registerField(user, errorLabel: userErrorLabel, rules: [RequiredRule(message: "Campo obrigatório")])
        validator.registerField(companyCode, errorLabel: companyCodeErrorLabel, rules: [RequiredRule(message: "Campo obrigatório")])
        validator.registerField(password, errorLabel: passwordErrorLabel, rules: [RequiredRule(message: "Campo obrigatório")])
        
    }
    
    //MARK : ACTION
    @IBAction func forgetPassword(sender: AnyObject) {
    }
    
    @IBAction func signIn(sender: AnyObject) {
        validator.validate(self)
        
    }
    
    //MARK: TEXTFIELD DELEGATE
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    // MARK: ValidationDelegate Methods
    
    func validationSuccessful() {
        print("Validation Success!")
        self.loginToServer()
        
    }
    
    
    func validationFailed(errors:[UITextField:ValidationError]) {
        
        print("validation failed")
    }
    
    
    //MARK: - Server
    
    func loginToServer(){
        //deal with passenger or driver
        
        self.activityIndicator.startAnimating()
        
        ServerManager.loginToServer(self.companyCode.text!, username: self.user.text!, password: self.password.text!) { (isPassenger, success, errorMessage) -> Void in
            
            //async
            
            dispatch_async(dispatch_get_main_queue()) {
                
                
                if (success) {
                    if self.isViewLoaded() && self.view.window != nil {
                        self.activityIndicator.stopAnimating()
                    }
                    
                    if isPassenger {
                        
                        self.performSegueWithIdentifier(self.showPassengerSegue, sender: self)
                        
                    }else{
                        self.performSegueWithIdentifier(self.showDriverSegue, sender: self)
                    }
                    
                    //save to user defaults
                    UserDefaultsLogin.name = ServerManager.user?.name
                    UserDefaultsLogin.email = ServerManager.user?.email
                    UserDefaultsLogin.companyCode = ServerManager.user?.companyCode
                    UserDefaultsLogin.password = ServerManager.user?.password
                    UserDefaultsLogin.telephone = ServerManager.user?.telphone
                    UserDefaultsLogin.isPassenger = isPassenger
                }else {
                    if self.isViewLoaded() && self.view.window != nil {
                        self.activityIndicator.stopAnimating()
                    }
                    EventsTrigger.triggerServerFeedbackEvent(success, errorMessage: errorMessage)
                    
                }
            }
            
        }
        
    }
    
    
    
}
